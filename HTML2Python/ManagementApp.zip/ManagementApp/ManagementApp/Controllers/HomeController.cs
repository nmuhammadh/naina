﻿using CsvHelper;
using ManagementApp.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Globalization;

namespace ManagementApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        IConfiguration _config;

        public HomeController(ILogger<HomeController> logger, IConfiguration config)
        {
            _logger = logger;
            _config = config;
        }

        private List<PythonScript> GetScripts()
        {
            var scripts = new List<PythonScript>();

            DirectoryInfo directoryInfo = new DirectoryInfo("Data\\scripts");
            var files = directoryInfo.GetFiles();
            StreamReader streamReader;
            string? line;
            PythonScript script;
            string[] paramOptions;

            foreach (var file in files)
            {
                script = new PythonScript();
                script.fileName = file.FullName;

                using (streamReader = new StreamReader(file.OpenRead()))
                {
                    do
                    {
                        line = streamReader.ReadLine();
                        if (line == null || !line.StartsWith("#")) break;
                        if (line.StartsWith("#Category:")) script.Category = line["#Category:".Length..];
                        if (line.StartsWith("#Title:")) script.Title = line["#Title:".Length..];
                        if (line.StartsWith("#Description:")) script.Description = line["#Description:".Length..];

                        if (line.StartsWith("#Param:"))
                        {
                            paramOptions = line["#Param:".Length..].Split("##");
                            script.Parameters.Add(new PythonScriptParameter()
                            {
                                Name = paramOptions[0],
                                ParamType = paramOptions[1],
                                Description = paramOptions[2]
                            });
                        }
                    }
                    while (true);
                    streamReader.Close();
                }
                scripts.Add(script);
            }

            return scripts;
        }
        private List<IPAddress> GetIPs()
        {
            List<IPAddress> ips = new List<IPAddress>();
            using (var reader = new StreamReader("Data\\IP\\data.csv"))
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {
                ips = csv.GetRecords<IPAddress>() .ToList();
            }
            return ips;
        }
        public ContentResult ExecuteResult(string ip, string fileName)
        {
            
            System.Diagnostics.Process process = new System.Diagnostics.Process();
            process.StartInfo = new System.Diagnostics.ProcessStartInfo()
            {
                UseShellExecute = false,
                CreateNoWindow = true,
                WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden,
                FileName = _config.GetValue<string>("executable"),
                Arguments = $"{fileName} {ip}",
                RedirectStandardError = true,
                RedirectStandardOutput = true
            };
            process.Start();
            // Now read the value, parse to int and add 1 (from the original script)
            string output = process.StandardOutput.ReadToEnd();
            process.WaitForExit();

            return new ContentResult()
            {
                Content = output,
                StatusCode = 200,
                ContentType = "plain/text"
            };
        }

        public IActionResult Index()
        {
            ViewData["scripts"] = GetScripts();
            ViewData["ips"] = GetIPs();
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}