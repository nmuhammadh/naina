#Category: Test
#Title: Hello World
#Description: Hello World
import sys

print('Hello, World!')


print("I will execute this script on " + sys.argv[1] + " ip address")