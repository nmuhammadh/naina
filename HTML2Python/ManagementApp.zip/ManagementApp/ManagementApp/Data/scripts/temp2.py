#Category: Device Status
#Title: Check Device Status

import sys

print("I will check the device status for " + sys.argv[1] + " ip")

fruits = ["apple", "banana", "cherry"]
for x in fruits:
  print(x)