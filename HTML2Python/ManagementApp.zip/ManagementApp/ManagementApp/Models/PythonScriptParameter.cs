﻿#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.
namespace ManagementApp.Models
{
    public class PythonScriptParameter
    {
        public string Name { get; set; }
        public string Description { get; set; }        
        public string ParamType { get; set; }
    }
}
