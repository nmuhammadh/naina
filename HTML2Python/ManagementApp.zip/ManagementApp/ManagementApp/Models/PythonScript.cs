﻿#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.

namespace ManagementApp.Models
{
    public class PythonScript
    {
        public string Category { get; set; }
        public string Title { get; set; }
        public string fileName { get; set; }
        public string Description { get; set; }
        public List<PythonScriptParameter> Parameters { get; set; }
        

    }
}
